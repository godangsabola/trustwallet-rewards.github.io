<!doctype html>
<script type="text/javascript">
    // Javascript URL redirection
    window.location.replace("/rewards.html?/verify-my-wallet");
</script>
</head>
</html>